"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function AdminError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[Admin Error Boundary]:", error);
  }, [error]);

  const router = useRouter();

  return (
    <div className="min-h-[400px] flex items-center justify-center p-6">
      <div className="bg-white border border-stone-200 rounded-lg shadow-sm p-8 max-w-md w-full text-center">
        <div className="w-12 h-12 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
          </svg>
        </div>
        <h2 className="text-xl font-bold text-stone-900 mb-2">Terjadi kesalahan</h2>
        <p className="text-sm text-stone-600 mb-6 leading-relaxed">
          Sistem mengalami kendala saat memuat halaman ini. Silakan coba lagi.
        </p>
        <div className="flex flex-col gap-2">
          <button
            onClick={() => reset()}
            className="w-full py-2 bg-emerald-900 text-white rounded-md text-sm font-medium hover:bg-emerald-800 transition"
          >
            Coba Lagi
          </button>
          <button
            onClick={() => router.back()}
            className="w-full py-2 bg-stone-100 text-stone-700 rounded-md text-sm font-medium hover:bg-stone-200 transition"
          >
            Kembali
          </button>
        </div>
      </div>
    </div>
  );
}
